-- Migração inicial para o aplicativo de Gestão de Antecipação de Recebíveis

-- Tabela de Usuários
CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    senha TEXT NOT NULL,
    perfil TEXT NOT NULL CHECK (perfil IN ('administrador', 'operador')),
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    data_criacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Clientes
CREATE TABLE IF NOT EXISTS clientes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    documento TEXT NOT NULL UNIQUE,
    tipo_documento TEXT NOT NULL CHECK (tipo_documento IN ('cpf', 'cnpj')),
    telefone TEXT,
    email TEXT,
    endereco TEXT,
    cidade TEXT,
    estado TEXT,
    cep TEXT,
    observacoes TEXT,
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    data_criacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Cheques
CREATE TABLE IF NOT EXISTS cheques (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cliente_id INTEGER NOT NULL,
    emitente TEXT NOT NULL,
    numero TEXT NOT NULL,
    valor REAL NOT NULL,
    data_vencimento DATE NOT NULL,
    banco TEXT NOT NULL,
    agencia TEXT NOT NULL,
    conta_corrente TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente', 'antecipado', 'liquidado', 'devolvido')),
    data_criacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (cliente_id) REFERENCES clientes (id)
);

-- Tabela de Boletos
CREATE TABLE IF NOT EXISTS boletos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cliente_id INTEGER NOT NULL,
    cedente TEXT NOT NULL,
    sacado TEXT NOT NULL,
    numero_nota_fiscal TEXT NOT NULL,
    valor REAL NOT NULL,
    data_vencimento DATE NOT NULL,
    status TEXT NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente', 'antecipado', 'liquidado', 'protestado')),
    data_criacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (cliente_id) REFERENCES clientes (id)
);

-- Tabela de Antecipações
CREATE TABLE IF NOT EXISTS antecipacoes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cliente_id INTEGER NOT NULL,
    data_operacao DATE NOT NULL,
    valor_total REAL NOT NULL,
    taxa_mensal REAL NOT NULL,
    valor_liquido REAL NOT NULL,
    observacoes TEXT,
    usuario_id INTEGER NOT NULL,
    data_criacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (cliente_id) REFERENCES clientes (id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
);

-- Tabela de Itens de Antecipação (relaciona antecipações com cheques e boletos)
CREATE TABLE IF NOT EXISTS itens_antecipacao (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    antecipacao_id INTEGER NOT NULL,
    tipo_recebivel TEXT NOT NULL CHECK (tipo_recebivel IN ('cheque', 'boleto')),
    recebivel_id INTEGER NOT NULL,
    valor_face REAL NOT NULL,
    dias_antecipados INTEGER NOT NULL,
    taxa_aplicada REAL NOT NULL,
    valor_descontado REAL NOT NULL,
    valor_liquido REAL NOT NULL,
    data_criacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (antecipacao_id) REFERENCES antecipacoes (id)
);

-- Índices para melhorar a performance
CREATE INDEX IF NOT EXISTS idx_cheques_cliente_id ON cheques (cliente_id);
CREATE INDEX IF NOT EXISTS idx_cheques_vencimento ON cheques (data_vencimento);
CREATE INDEX IF NOT EXISTS idx_cheques_status ON cheques (status);

CREATE INDEX IF NOT EXISTS idx_boletos_cliente_id ON boletos (cliente_id);
CREATE INDEX IF NOT EXISTS idx_boletos_vencimento ON boletos (data_vencimento);
CREATE INDEX IF NOT EXISTS idx_boletos_status ON boletos (status);

CREATE INDEX IF NOT EXISTS idx_antecipacoes_cliente_id ON antecipacoes (cliente_id);
CREATE INDEX IF NOT EXISTS idx_antecipacoes_data ON antecipacoes (data_operacao);

CREATE INDEX IF NOT EXISTS idx_itens_antecipacao_id ON itens_antecipacao (antecipacao_id);
CREATE INDEX IF NOT EXISTS idx_itens_tipo_recebivel ON itens_antecipacao (tipo_recebivel, recebivel_id);

-- Inserir um usuário administrador padrão (senha: admin123)
INSERT INTO usuarios (nome, email, senha, perfil) 
VALUES ('Administrador', 'admin@sistema.com', 'admin123', 'administrador');
