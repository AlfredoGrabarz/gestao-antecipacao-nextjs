-- Migração para adicionar suporte a autenticação e sessões

-- Alterar a tabela de usuários para usar hash de senha
ALTER TABLE usuarios RENAME COLUMN senha TO senha_hash;

-- Criar tabela de sessões
CREATE TABLE IF NOT EXISTS sessoes (
    id TEXT PRIMARY KEY,
    usuario_id INTEGER NOT NULL,
    data_expiracao TIMESTAMP NOT NULL,
    data_criacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
);

-- Criar índice para melhorar a performance das consultas de sessão
CREATE INDEX IF NOT EXISTS idx_sessoes_usuario_id ON sessoes (usuario_id);
CREATE INDEX IF NOT EXISTS idx_sessoes_expiracao ON sessoes (data_expiracao);

-- A senha do usuário administrador padrão (ID 1, email admin@sistema.com, senha original admin123)
-- será atualizada para um hash bcrypt programaticamente após esta migração.
