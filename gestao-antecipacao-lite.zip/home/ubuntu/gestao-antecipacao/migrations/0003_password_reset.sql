-- Migração para adicionar tabela de tokens de redefinição de senha

CREATE TABLE IF NOT EXISTS password_reset_tokens (
    token TEXT PRIMARY KEY,
    usuario_id INTEGER NOT NULL,
    email TEXT NOT NULL, -- Adicionado para facilitar a busca e evitar joins desnecessários na validação inicial
    data_expiracao TIMESTAMP NOT NULL,
    data_criacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    utilizado BOOLEAN NOT NULL DEFAULT FALSE, -- Para garantir que o token seja usado apenas uma vez
    FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_usuario_id ON password_reset_tokens (usuario_id);
CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_expiracao ON password_reset_tokens (data_expiracao);

