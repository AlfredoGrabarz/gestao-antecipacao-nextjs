const bcrypt = require('bcryptjs');

async function testBcrypt() {
  console.log('Iniciando teste de unidade para bcryptjs...');
  const senhaOriginal = 'senhaSuperSegura123';
  const senhaIncorreta = 'senhaErrada456';
  let hashGerado = '';
  let testeBemSucedido = true;

  try {
    // Teste 1: Gerar hash
    const saltRounds = 10;
    hashGerado = await bcrypt.hash(senhaOriginal, saltRounds);
    console.log('Hash gerado:', hashGerado);
    if (!hashGerado.startsWith('$2a$')) {
      console.error('ERRO: Hash gerado não parece ser um hash bcrypt válido.');
      testeBemSucedido = false;
    }

    // Teste 2: Comparar senha correta com o hash
    const comparacaoCorreta = await bcrypt.compare(senhaOriginal, hashGerado);
    console.log('Comparação com senha correta (esperado: true):', comparacaoCorreta);
    if (!comparacaoCorreta) {
      console.error('ERRO: Comparação com senha correta falhou.');
      testeBemSucedido = false;
    }

    // Teste 3: Comparar senha incorreta com o hash
    const comparacaoIncorreta = await bcrypt.compare(senhaIncorreta, hashGerado);
    console.log('Comparação com senha incorreta (esperado: false):', comparacaoIncorreta);
    if (comparacaoIncorreta) {
      console.error('ERRO: Comparação com senha incorreta falhou (retornou true).');
      testeBemSucedido = false;
    }

  } catch (error) {
    console.error('ERRO DURANTE O TESTE BCRYPT:', error);
    testeBemSucedido = false;
  }

  if (testeBemSucedido) {
    console.log('SUCESSO: Testes de unidade para bcryptjs passaram.');
  } else {
    console.error('FALHA: Um ou mais testes de unidade para bcryptjs falharam.');
  }
  return testeBemSucedido;
}

testBcrypt();

