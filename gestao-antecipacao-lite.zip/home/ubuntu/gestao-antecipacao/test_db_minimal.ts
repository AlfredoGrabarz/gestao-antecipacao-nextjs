require("ts-node/register");
const { getDb, getAll } = require("./src/lib/db");

async function testDb() {
  console.log("Iniciando teste mínimo do db.ts...");
  try {
    const db = getDb();
    console.log("Instância do banco obtida.");

    // Tenta listar tabelas (exemplo de consulta)
    const tables = await getAll(db, "SELECT name FROM sqlite_master WHERE type=\'table\'");
    console.log("Tabelas no banco de dados:", tables);

    // Adicionar um teste de inserção e seleção simples
    await getAll(db, "CREATE TABLE IF NOT EXISTS test_table (id INTEGER PRIMARY KEY, name TEXT)");
    console.log("Tabela test_table verificada/criada.");

    const insertResult = await getAll(db, "INSERT INTO test_table (name) VALUES (?)", ["Teste Manu"]);
    console.log("Resultado da inserção:", insertResult);

    const selectedData = await getAll(db, "SELECT * FROM test_table");
    console.log("Dados selecionados da test_table:", selectedData);

    await getAll(db, "DROP TABLE test_table");
    console.log("Tabela test_table removida.");

    console.log("Teste mínimo do db.ts concluído com sucesso!");
  } catch (error) {
    console.error("Erro durante o teste mínimo do db.ts:", error);
  }
}

testDb();

