# Requisitos do Aplicativo de Gestão de Antecipação de Recebíveis

## Funcionalidades Principais:

1.  **Cadastro de Recebíveis:**
    *   **Cheques:** Registrar informações como cliente que forneceu o cheque, emitente do cheque, número do cheque, valor, data de vencimento, banco, agência e conta corrente.
    *   **Boletos:** Registrar informações como cliente que forneceu o boleto, cedente, sacado, número da nota fiscal associada, valor e data de vencimento.
2.  **Cálculo de Antecipação:**
    *   Permitir a aplicação de uma taxa de desconto mensal.
    *   A taxa deve ser configurável por cliente e por operação de antecipação no momento do cálculo.
3.  **Gerenciamento de Clientes:**
    *   Manter um cadastro detalhado dos clientes que utilizam o serviço de antecipação.
4.  **Gerenciamento de Usuários:**
    *   Implementar um sistema de login.
    *   Suportar diferentes perfis de usuário (ex: Administrador, Operador) com permissões distintas (a serem detalhadas posteriormente).
5.  **Relatórios:**
    *   Gerar relatórios como:
        *   Total antecipado por período (dia, semana, mês).
        *   Recebíveis cadastrados por cliente.
        *   Fluxo de caixa futuro baseado nos vencimentos.
        *   Outros relatórios que possam ser identificados como úteis durante o desenvolvimento.

## Requisitos Não Funcionais:

*   **Interface:** Interface web amigável e responsiva (adaptável a diferentes tamanhos de tela).
*   **Tecnologia:** A ser definida (provavelmente Next.js com banco de dados D1).
*   **Segurança:** Garantir a segurança dos dados e controle de acesso via perfis de usuário.
*   **Implantação:** O aplicativo deve ser implantável em ambiente web (ex: Cloudflare Pages/Workers).
