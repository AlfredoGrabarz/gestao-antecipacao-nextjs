// src/app/cheques/actions.ts
'use server';

import { getRequestContext } from '@cloudflare/next-on-pages';
import { revalidatePath } from 'next/cache';

interface ChequeFormData {
  cliente_id: number; // Assumindo que o cliente será selecionado ou buscado
  emitente: string;
  numero: string;
  valor: number;
  data_vencimento: string; // Formato YYYY-MM-DD
  banco: string;
  agencia: string;
  conta_corrente: string;
}

export async function createCheque(formData: ChequeFormData) {
  const { env } = getRequestContext();
  const db = env.DB;

  try {
    // TODO: Adicionar validação dos dados recebidos
    // TODO: Buscar o cliente_id real com base no nome/documento fornecido no formulário
    // Por enquanto, vamos usar um ID fixo para teste
    const clienteIdFixo = 1; 

    const stmt = db.prepare(
      `INSERT INTO cheques (cliente_id, emitente, numero, valor, data_vencimento, banco, agencia, conta_corrente, status) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pendente')`
    );
    
    const result = await stmt.bind(
      clienteIdFixo, // Usar o ID do cliente real posteriormente
      formData.emitente,
      formData.numero,
      formData.valor,
      formData.data_vencimento,
      formData.banco,
      formData.agencia,
      formData.conta_corrente
    ).run();

    console.log('Cheque inserido:', result);
    revalidatePath('/cheques'); // Atualiza o cache da página de cheques
    return { success: true, message: 'Cheque cadastrado com sucesso!' };

  } catch (error: any) {
    console.error('Erro ao cadastrar cheque:', error);
    return { success: false, message: `Erro ao cadastrar cheque: ${error.message}` };
  }
}

export async function getCheques() {
  const { env } = getRequestContext();
  const db = env.DB;

  try {
    const stmt = db.prepare(`
      SELECT c.*, cl.nome as cliente_nome
      FROM cheques c
      JOIN clientes cl ON c.cliente_id = cl.id
      ORDER BY c.data_vencimento ASC
    `);
    
    const result = await stmt.all();
    return { success: true, data: result.results };
  } catch (error: any) {
    console.error('Erro ao buscar cheques:', error);
    return { success: false, message: `Erro ao buscar cheques: ${error.message}`, data: [] };
  }
}

export async function updateChequeStatus(id: number, status: string) {
  const { env } = getRequestContext();
  const db = env.DB;

  try {
    const stmt = db.prepare(`
      UPDATE cheques
      SET status = ?, data_atualizacao = CURRENT_TIMESTAMP
      WHERE id = ?
    `);
    
    await stmt.bind(status, id).run();
    revalidatePath('/cheques');
    return { success: true, message: 'Status do cheque atualizado com sucesso!' };
  } catch (error: any) {
    console.error('Erro ao atualizar status do cheque:', error);
    return { success: false, message: `Erro ao atualizar status: ${error.message}` };
  }
}

export async function deleteCheque(id: number) {
  const { env } = getRequestContext();
  const db = env.DB;

  try {
    // Verificar se o cheque não está em uma antecipação
    const checkStmt = db.prepare(`
      SELECT COUNT(*) as count FROM itens_antecipacao 
      WHERE tipo_recebivel = 'cheque' AND recebivel_id = ?
    `);
    
    const checkResult = await checkStmt.bind(id).first();
    if (checkResult && checkResult.count > 0) {
      return { 
        success: false, 
        message: 'Este cheque não pode ser excluído pois está vinculado a uma antecipação.' 
      };
    }

    const stmt = db.prepare('DELETE FROM cheques WHERE id = ?');
    await stmt.bind(id).run();
    revalidatePath('/cheques');
    return { success: true, message: 'Cheque excluído com sucesso!' };
  } catch (error: any) {
    console.error('Erro ao excluir cheque:', error);
    return { success: false, message: `Erro ao excluir cheque: ${error.message}` };
  }
}
