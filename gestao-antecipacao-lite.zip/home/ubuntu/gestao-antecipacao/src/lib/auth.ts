// src/lib/auth.ts
import { getDb } from "./db"; // Modificado para usar o db helper local/D1
import { cookies } from "next/headers";
import bcrypt from "bcryptjs";
import { randomUUID } from "crypto";
import type { AppDatabase } from "./db"; // Importar o tipo AppDatabase

const SESSION_COOKIE_NAME = "gestao_antecipacao_session";
const SESSION_DURATION_MS = 7 * 24 * 60 * 60 * 1000; // 7 dias
const PASSWORD_RESET_TOKEN_DURATION_MS = 1 * 60 * 60 * 1000; // 1 hora

export interface UserSession {
  id: number;
  nome: string;
  email: string;
  perfil: string;
}

// Cria uma nova sessão para o usuário
async function createSession(userId: number): Promise<string | null> {
  const db: AppDatabase = getDb();
  const sessionId: string = randomUUID();
  const expirationDate: Date = new Date(Date.now() + SESSION_DURATION_MS);

  try {
    // A query original era para D1. Adaptar para better-sqlite3 se necessário.
    // No nosso db.ts, executeQuery já lida com a diferença.
    await getDb().prepare(
      "INSERT INTO sessoes (id, usuario_id, data_expiracao) VALUES (?, ?, ?)"
    ).run(sessionId, userId, expirationDate.toISOString());
    return sessionId;
  } catch (error: any) {
    console.error("Erro ao criar sessão:", error);
    return null;
  }
}

// Busca uma sessão válida pelo ID
async function getSessionById(sessionId: string): Promise<UserSession | null> {
  const db: AppDatabase = getDb();

  try {
    const stmt = db.prepare(`
      SELECT u.id, u.nome, u.email, u.perfil 
      FROM sessoes s
      JOIN usuarios u ON s.usuario_id = u.id
      WHERE s.id = ? AND s.data_expiracao > CURRENT_TIMESTAMP AND u.ativo = 1
    `);
    // getFirst já lida com a diferença D1/better-sqlite3 e retorna Promise
    const result = await getDb().prepare(`
    SELECT u.id, u.nome, u.email, u.perfil 
    FROM sessoes s
    JOIN usuarios u ON s.usuario_id = u.id
    WHERE s.id = ? AND DATETIME(s.data_expiracao) > DATETIME(\'now\') AND u.ativo = 1
  `).get(sessionId) as UserSession | undefined;
    return result || null;
  } catch (error: any) {
    console.error("Erro ao buscar sessão:", error);
    return null;
  }
}

// Deleta uma sessão
async function deleteSession(sessionId: string): Promise<boolean> {
  const db: AppDatabase = getDb();

  try {
    await getDb().prepare("DELETE FROM sessoes WHERE id = ?").run(sessionId);
    return true;
  } catch (error: any) {
    console.error("Erro ao deletar sessão:", error);
    return false;
  }
}

// Função de Login
export async function login(email: string, senha: string): Promise<{ success: boolean; message: string; user?: UserSession }> {
  const db: AppDatabase = getDb();

  try {
    const userRow = await getDb().prepare(
      "SELECT id, nome, email, perfil, senha_hash, ativo FROM usuarios WHERE email = ?"
    ).get(email) as { id: number; nome: string; email: string; perfil: string; senha_hash: string; ativo: number } | undefined;

    if (!userRow) {
      return { success: false, message: "Email não encontrado." };
    }

    if (!userRow.ativo) {
      return { success: false, message: "Usuário inativo." };
    }

    const isPasswordValid: boolean = await bcrypt.compare(senha, userRow.senha_hash);

    if (!isPasswordValid) {
      return { success: false, message: "Senha incorreta." };
    }

    const sessionId: string | null = await createSession(userRow.id);
    if (!sessionId) {
      return { success: false, message: "Erro ao criar sessão." };
    }
    
    // A API cookies() de next/headers é síncrona para .set e .get em Server Actions/Route Handlers
    // O erro de tipagem anterior era estranho. Vamos tentar novamente.
    cookies().set(SESSION_COOKIE_NAME, sessionId, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      maxAge: SESSION_DURATION_MS / 1000,
      path: "/",
      sameSite: "lax",
    });
    
    const userSessionData: UserSession = {
        id: userRow.id,
        nome: userRow.nome,
        email: userRow.email,
        perfil: userRow.perfil
    };

    return { success: true, message: "Login realizado com sucesso!", user: userSessionData };

  } catch (error: any) {
    console.error("Erro no login:", error);
    return { success: false, message: "Erro interno no servidor durante o login." };
  }
}

// Função de Logout
export async function logout(): Promise<void> {
  const sessionId: string | undefined = cookies().get(SESSION_COOKIE_NAME)?.value;
  if (sessionId) {
    await deleteSession(sessionId);
  }
  cookies().set(SESSION_COOKIE_NAME, "", {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    maxAge: -1, 
    path: "/",
    sameSite: "lax",
  });
}

export async function getCurrentUserSession(): Promise<UserSession | null> {
  const sessionId: string | undefined = cookies().get(SESSION_COOKIE_NAME)?.value;
  if (!sessionId) {
    return null;
  }
  return await getSessionById(sessionId);
}

export async function requireAuth(requiredProfile?: string | string[]): Promise<UserSession> {
  const user: UserSession | null = await getCurrentUserSession();
  if (!user) {
    // Em vez de lançar erro diretamente, poderia redirecionar ou retornar um status específico
    // Para Server Components/Actions, lançar erro pode ser ok se tratado adequadamente.
    throw new Error("AUTH_REQUIRED: Usuário não autenticado."); 
  }
  if (requiredProfile) {
    const profiles: string[] = Array.isArray(requiredProfile) ? requiredProfile : [requiredProfile];
    if (!profiles.includes(user.perfil)) {
      throw new Error("AUTH_FORBIDDEN: Usuário não autorizado para este recurso.");
    }
  }
  return user;
}

// Solicitar redefinição de senha
export async function requestPasswordReset(email: string): Promise<{ success: boolean; message: string }> {
  const db: AppDatabase = getDb();

  try {
    const user = await getDb().prepare("SELECT id, ativo FROM usuarios WHERE email = ?")
        .get(email) as { id: number; ativo: number } | undefined;

    if (!user || !user.ativo) {
      // Não revelar se o e-mail existe ou não por segurança, nem se está inativo
      return { success: true, message: "Se o e-mail estiver cadastrado em nosso sistema e ativo, você receberá um link para redefinir sua senha." };
    }

    const token: string = randomUUID();
    const expirationDate: Date = new Date(Date.now() + PASSWORD_RESET_TOKEN_DURATION_MS);

    await getDb().prepare(
      "INSERT INTO password_reset_tokens (token, usuario_id, email, data_expiracao) VALUES (?, ?, ?, ?)"
    ).run(token, user.id, email, expirationDate.toISOString());

    console.log(`Link de redefinição para ${email}: /redefinir-senha?token=${token}`); // Simulação

    return { success: true, message: "Se o e-mail estiver cadastrado em nosso sistema e ativo, você receberá um link para redefinir sua senha." };
  } catch (error: any) {
    console.error("Erro ao solicitar redefinição de senha:", error);
    return { success: false, message: "Ocorreu um erro ao processar sua solicitação. Tente novamente mais tarde." };
  }
}

// Verificar token de redefinição de senha
export async function verifyPasswordResetToken(token: string): Promise<{ valid: boolean; email?: string; message?: string }> {
  const db: AppDatabase = getDb();
  try {
    const tokenData = await getDb().prepare(
      "SELECT usuario_id, email, data_expiracao, utilizado FROM password_reset_tokens WHERE token = ? AND DATETIME(data_expiracao) > DATETIME(\'now\') AND utilizado = 0"
    ).get(token) as { usuario_id: number; email: string; data_expiracao: string; utilizado: number } | undefined;

    if (!tokenData) {
      // Tenta buscar um token que pode estar expirado ou já utilizado para dar uma mensagem mais específica
      const existingToken = await getDb().prepare(
        "SELECT data_expiracao, utilizado FROM password_reset_tokens WHERE token = ?"
      ).get(token) as { data_expiracao: string; utilizado: number } | undefined;

      if (existingToken) {
        if (existingToken.utilizado) return { valid: false, message: "Este token já foi utilizado." };
        if (new Date(existingToken.data_expiracao) < new Date()) return { valid: false, message: "Token expirado." };
      }
      return { valid: false, message: "Token inválido ou não encontrado." };
    }
    return { valid: true, email: tokenData.email };
  } catch (error: any) {
    console.error("Erro ao verificar token de redefinição:", error);
    return { valid: false, message: "Erro ao verificar o token." };
  }
}

// Redefinir a senha usando o token
export async function resetPassword(token: string, novaSenha: string): Promise<{ success: boolean; message: string }> {
  const db: AppDatabase = getDb();

  try {
    const verification = await verifyPasswordResetToken(token);
    if (!verification.valid || !verification.email) {
      return { success: false, message: verification.message || "Token inválido ou expirado." };
    }

    if (novaSenha.length < 6) {
      return { success: false, message: "A nova senha deve ter pelo menos 6 caracteres." };
    }

    const saltRounds: number = 10;
    const senhaHash: string = await bcrypt.hash(novaSenha, saltRounds);

    const updateResult: Database.RunResult = await getDb().prepare("UPDATE usuarios SET senha_hash = ? WHERE email = ?")
        .run(senhaHash, verification.email);
    
    if(updateResult.changes === 0){
        return { success: false, message: "Não foi possível atualizar a senha. Usuário não encontrado." };
    }

    await getDb().prepare("UPDATE password_reset_tokens SET utilizado = 1 WHERE token = ?").run(token);

    return { success: true, message: "Senha redefinida com sucesso! Você já pode fazer login com sua nova senha." };
  } catch (error: any) {
    console.error("Erro ao redefinir senha:", error);
    return { success: false, message: "Ocorreu um erro ao redefinir sua senha. Tente novamente mais tarde." };
  }
}

