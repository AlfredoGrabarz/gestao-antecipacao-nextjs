// import initSqlJs from "sql.js"; // Comentado para usar require dinâmico
import path from "path";
import fs from "fs";

// Tipos para sql.js - Manter para referência, mas a importação será dinâmica
// export type SQLJsDatabase = initSqlJs.Database;
// export type SQLJsStatic = initSqlJs.SqlJsStatic;

let dbInstance: any | undefined; // Usar any por enquanto devido ao require dinâmico
let SQL: any | undefined; // Usar any por enquanto

const localDbFileName: string = "gestao_antecipacao_local.sqlite";
const localDbDir: string = path.resolve(process.cwd(), "db_data");
const localDbPath: string = path.join(localDbDir, localDbFileName);

async function initializeLocalDb(): Promise<any> {
    console.log(`Attempting to initialize SQL.js database...`);

    if (!SQL) {
        const initSqlJs = require("sql.js"); // Importação dinâmica
        SQL = await initSqlJs({
            // locateFile: file => `https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.13.0/${file}`
        });
        console.log("SQL.js static library initialized dynamically.");
    }

    if (!fs.existsSync(localDbDir)) {
        fs.mkdirSync(localDbDir, { recursive: true });
        console.log(`Directory ${localDbDir} created.`);
    }

    let db: any;
    try {
        if (fs.existsSync(localDbPath)) {
            console.log(`Loading existing database file from: ${localDbPath}`);
            const fileBuffer = fs.readFileSync(localDbPath);
            db = new SQL.Database(fileBuffer);
            console.log("Database loaded from file.");
        } else {
            console.log(`Creating new in-memory database (will be saved to ${localDbPath} on close if changes are made).`);
            db = new SQL.Database();
            const data = db.export();
            fs.writeFileSync(localDbPath, Buffer.from(data));
            console.log("New database file created.");
        }
        db.exec("PRAGMA foreign_keys = ON;");
        console.log("SQL.js database instance created/loaded and foreign keys enabled.");
        return db;
    } catch (e: any) {
        console.error("Error initializing SQL.js database:", e);
        throw e;
    }
}

export async function getDb(): Promise<any> {
    if (!dbInstance) {
        console.log("Executing in local environment, initializing SQL.js database...");
        dbInstance = await initializeLocalDb();
    }
    return dbInstance;
}

export interface RunResult {
    changes: number; 
    lastID: number; 
}

export async function executeQuery(db: any, query: string, params: any[] = []): Promise<RunResult> {
    try {
        db.run(query, params); 
        const changes = db.getRowsModified();
        let lastID = 0;
        if (query.trim().toUpperCase().startsWith("INSERT")) {
            const stmt = db.prepare("SELECT last_insert_rowid()");
            stmt.step();
            const result = stmt.getAsObject();
            lastID = result.last_insert_rowid as number;
            stmt.free();
        }
        return { changes, lastID };
    } catch (e: any) {
        console.error("Error in executeQuery with sql.js:", query, params, e);
        throw e;
    }
}

export async function getFirst(db: any, query: string, params: any[] = []): Promise<any | null> {
    try {
        const stmt = db.prepare(query, params);
        let result = null;
        if (stmt.step()) {
            result = stmt.getAsObject();
        }
        stmt.free();
        return result;
    } catch (e: any) {
        console.error("Error in getFirst with sql.js:", query, params, e);
        throw e;
    }
}

export async function getAll(db: any, query: string, params: any[] = []): Promise<any[]> {
    try {
        const stmt = db.prepare(query, params);
        const results: any[] = [];
        while (stmt.step()) {
            results.push(stmt.getAsObject());
        }
        stmt.free();
        return results;
    } catch (e: any) {
        console.error("Error in getAll with sql.js:", query, params, e);
        throw e;
    }
}

export async function saveDb(db: any): Promise<void> {
    if (!db) return;
    try {
        console.log(`Saving database to ${localDbPath}...`);
        const data = db.export();
        fs.writeFileSync(localDbPath, Buffer.from(data));
        console.log("Database saved successfully.");
    } catch (e: any) {
        console.error("Error saving database:", e);
        throw e;
    }
}

export async function closeDb(db: any): Promise<void> {
    if (!db) return;
    try {
        await saveDb(db);
        db.close();
        dbInstance = undefined;
        SQL = undefined;
        console.log("SQL.js database closed and instance reset.");
    } catch (e: any) {
        console.error("Error closing SQL.js database:", e);
        throw e;
    }
}

