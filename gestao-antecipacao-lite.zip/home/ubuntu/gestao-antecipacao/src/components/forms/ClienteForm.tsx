
'use client';

import { useState } from 'react';
import { createCliente } from '@/app/clientes/actions'; // Importar a server action

// TODO: Adicionar prop para edição de cliente existente
export default function ClienteForm() {
  const initialFormData = {
    nome: '',
    documento: '',
    tipo_documento: 'cpf',
    telefone: '',
    email: '',
    endereco: '',
    cidade: '',
    estado: '',
    cep: '',
    observacoes: '',
    ativo: true,
  };
  const [formData, setFormData] = useState(initialFormData);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    const checked = (e.target as HTMLInputElement).checked;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
    setMessage(null); // Limpar mensagem ao alterar campo
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setMessage(null);

    try {
      const result = await createCliente(formData);
      if (result.success) {
        setMessage({ type: 'success', text: result.message });
        setFormData(initialFormData); // Limpar formulário
      } else {
        setMessage({ type: 'error', text: result.message });
      }
    } catch (error) {
      console.error('Erro inesperado no formulário de cliente:', error);
      setMessage({ type: 'error', text: 'Ocorreu um erro inesperado ao cadastrar o cliente.' });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="bg-gray-800 p-6 rounded-lg shadow-md">
      {message && (
        <p className={`mb-4 text-sm ${message.type === 'success' ? 'text-green-400' : 'text-red-400'}`}>
          {message.text}
        </p>
      )}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="mb-4 md:col-span-2">
          <label htmlFor="nome" className="block text-sm font-medium mb-1">Nome / Razão Social</label>
          <input
            type="text"
            id="nome"
            name="nome"
            value={formData.nome}
            onChange={handleChange}
            required
            className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-white"
          />
        </div>

        <div className="mb-4">
          <label htmlFor="tipo_documento" className="block text-sm font-medium mb-1">Tipo Documento</label>
          <select
            id="tipo_documento"
            name="tipo_documento"
            value={formData.tipo_documento}
            onChange={handleChange}
            required
            className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-white"
          >
            <option value="cpf">CPF</option>
            <option value="cnpj">CNPJ</option>
          </select>
        </div>

        <div className="mb-4">
          <label htmlFor="documento" className="block text-sm font-medium mb-1">Documento (CPF/CNPJ)</label>
          <input
            type="text"
            id="documento"
            name="documento"
            value={formData.documento}
            onChange={handleChange}
            required
            // TODO: Adicionar máscara de input
            className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-white"
          />
        </div>

        <div className="mb-4">
          <label htmlFor="email" className="block text-sm font-medium mb-1">Email</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-white"
          />
        </div>

        <div className="mb-4">
          <label htmlFor="telefone" className="block text-sm font-medium mb-1">Telefone</label>
          <input
            type="tel"
            id="telefone"
            name="telefone"
            value={formData.telefone}
            onChange={handleChange}
            // TODO: Adicionar máscara de input
            className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-white"
          />
        </div>

        <div className="mb-4 md:col-span-2">
          <label htmlFor="endereco" className="block text-sm font-medium mb-1">Endereço</label>
          <input
            type="text"
            id="endereco"
            name="endereco"
            value={formData.endereco}
            onChange={handleChange}
            className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-white"
          />
        </div>

        <div className="mb-4">
          <label htmlFor="cidade" className="block text-sm font-medium mb-1">Cidade</label>
          <input
            type="text"
            id="cidade"
            name="cidade"
            value={formData.cidade}
            onChange={handleChange}
            className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-white"
          />
        </div>

        <div className="mb-4">
          <label htmlFor="estado" className="block text-sm font-medium mb-1">Estado</label>
          <input
            type="text"
            id="estado"
            name="estado"
            value={formData.estado}
            onChange={handleChange}
            maxLength={2} // Ex: SP, RJ
            className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-white"
          />
        </div>

        <div className="mb-4">
          <label htmlFor="cep" className="block text-sm font-medium mb-1">CEP</label>
          <input
            type="text"
            id="cep"
            name="cep"
            value={formData.cep}
            onChange={handleChange}
            // TODO: Adicionar máscara de input
            className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-white"
          />
        </div>

        <div className="mb-4 md:col-span-2">
          <label htmlFor="observacoes" className="block text-sm font-medium mb-1">Observações</label>
          <textarea
            id="observacoes"
            name="observacoes"
            value={formData.observacoes}
            onChange={handleChange}
            rows={3}
            className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-white"
          />
        </div>

        <div className="mb-4 flex items-center">
          <input
            type="checkbox"
            id="ativo"
            name="ativo"
            checked={formData.ativo}
            onChange={handleChange}
            className="mr-2 h-4 w-4 rounded border-gray-500 text-blue-600 focus:ring-blue-500 bg-gray-800"
          />
          <label htmlFor="ativo" className="text-sm font-medium">Cliente Ativo</label>
        </div>
      </div>

      <div className="mt-6">
        <button
          type="submit"
          disabled={isLoading}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? 'Cadastrando...' : 'Cadastrar Cliente'}
        </button>
      </div>
    </form>
  );
}

