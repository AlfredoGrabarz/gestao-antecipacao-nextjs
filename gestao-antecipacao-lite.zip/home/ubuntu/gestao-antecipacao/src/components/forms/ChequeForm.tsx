
'use client';

import { useState } from 'react';
import { createCheque } from '@/app/cheques/actions'; // Importar a server action

export default function ChequeForm() {
  const [formData, setFormData] = useState({
    cliente: '', // Manter como string por enquanto, backend buscará ID
    emitente: '',
    numero: '',
    valor: '',
    dataVencimento: '',
    banco: '',
    agencia: '',
    contaCorrente: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    setMessage(null); // Limpar mensagem ao alterar campo
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setMessage(null);

    // Preparar dados para a action (converter valor para número)
    const dataToSend = {
      cliente_id: 1, // ID Fixo para teste - TODO: Implementar busca/seleção de cliente
      emitente: formData.emitente,
      numero: formData.numero,
      valor: parseFloat(formData.valor),
      data_vencimento: formData.dataVencimento,
      banco: formData.banco,
      agencia: formData.agencia,
      conta_corrente: formData.contaCorrente
    };

    // Validar valor
    if (isNaN(dataToSend.valor) || dataToSend.valor <= 0) {
      setMessage({ type: 'error', text: 'Valor inválido.' });
      setIsLoading(false);
      return;
    }

    try {
      const result = await createCheque(dataToSend);
      if (result.success) {
        setMessage({ type: 'success', text: result.message });
        // Limpar o formulário após o envio bem-sucedido
        setFormData({
          cliente: '',
          emitente: '',
          numero: '',
          valor: '',
          dataVencimento: '',
          banco: '',
          agencia: '',
          contaCorrente: ''
        });
      } else {
        setMessage({ type: 'error', text: result.message });
      }
    } catch (error) {
      console.error('Erro inesperado no formulário:', error);
      setMessage({ type: 'error', text: 'Ocorreu um erro inesperado ao cadastrar o cheque.' });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="bg-gray-800 p-6 rounded-lg shadow-md">
      {message && (
        <p className={`mb-4 text-sm ${message.type === 'success' ? 'text-green-400' : 'text-red-400'}`}>
          {message.text}
        </p>
      )}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* TODO: Substituir input de texto por select/autocomplete para cliente */}
        <div className="mb-4">
          <label htmlFor="cliente" className="block text-sm font-medium mb-1">
            Cliente que deu o cheque (ID Fixo: 1)
          </label>
          <input
            type="text"
            id="cliente"
            name="cliente"
            value={formData.cliente}
            onChange={handleChange}
            required
            placeholder="Nome ou ID do cliente"
            className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-white"
          />
        </div>

        <div className="mb-4">
          <label htmlFor="emitente" className="block text-sm font-medium mb-1">
            Emitente do cheque
          </label>
          <input
            type="text"
            id="emitente"
            name="emitente"
            value={formData.emitente}
            onChange={handleChange}
            required
            className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-white"
          />
        </div>

        <div className="mb-4">
          <label htmlFor="numero" className="block text-sm font-medium mb-1">
            Número do cheque
          </label>
          <input
            type="text"
            id="numero"
            name="numero"
            value={formData.numero}
            onChange={handleChange}
            required
            className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-white"
          />
        </div>

        <div className="mb-4">
          <label htmlFor="valor" className="block text-sm font-medium mb-1">
            Valor do cheque (R$)
          </label>
          <input
            type="number"
            id="valor"
            name="valor"
            value={formData.valor}
            onChange={handleChange}
            required
            step="0.01"
            min="0.01"
            className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-white"
          />
        </div>

        <div className="mb-4">
          <label htmlFor="dataVencimento" className="block text-sm font-medium mb-1">
            Data de vencimento
          </label>
          <input
            type="date"
            id="dataVencimento"
            name="dataVencimento"
            value={formData.dataVencimento}
            onChange={handleChange}
            required
            className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-white"
          />
        </div>

        <div className="mb-4">
          <label htmlFor="banco" className="block text-sm font-medium mb-1">
            Banco
          </label>
          <input
            type="text"
            id="banco"
            name="banco"
            value={formData.banco}
            onChange={handleChange}
            required
            className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-white"
          />
        </div>

        <div className="mb-4">
          <label htmlFor="agencia" className="block text-sm font-medium mb-1">
            Agência
          </label>
          <input
            type="text"
            id="agencia"
            name="agencia"
            value={formData.agencia}
            onChange={handleChange}
            required
            className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-white"
          />
        </div>

        <div className="mb-4">
          <label htmlFor="contaCorrente" className="block text-sm font-medium mb-1">
            Conta Corrente
          </label>
          <input
            type="text"
            id="contaCorrente"
            name="contaCorrente"
            value={formData.contaCorrente}
            onChange={handleChange}
            required
            className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-white"
          />
        </div>
      </div>

      <div className="mt-6">
        <button
          type="submit"
          disabled={isLoading}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? 'Cadastrando...' : 'Cadastrar Cheque'}
        </button>
      </div>
    </form>
  );
}

