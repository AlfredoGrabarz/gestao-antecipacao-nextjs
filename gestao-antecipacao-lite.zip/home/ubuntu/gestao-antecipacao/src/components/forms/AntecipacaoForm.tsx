
'use client';

import { useState, useMemo } from 'react';
import { createAntecipacao } from '@/app/antecipacoes/actions'; // Importar a server action

interface Recebivel {
  id: string;
  tipo: 'cheque' | 'boleto';
  descricao: string;
  valor: number;
  vencimento: string;
}

interface AntecipacaoFormProps {
  recebiveisDisponiveis: Recebivel[];
}

interface CalculoResultado {
  valorTotalFace: number;
  valorTotalDesconto: number;
  valorTotalLiquido: number;
  detalhes: { id: string; valorFace: number; dias: number; desconto: number; liquido: number }[];
}

export default function AntecipacaoForm({ recebiveisDisponiveis }: AntecipacaoFormProps) {
  const [selectedRecebiveisIds, setSelectedRecebiveisIds] = useState<string[]>([]);
  const [taxaMensal, setTaxaMensal] = useState<string>('2.99'); // Taxa mensal em %
  const [dataOperacao] = useState(new Date()); // Data da operação (hoje)
  const [resultadoCalculo, setResultadoCalculo] = useState<CalculoResultado | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value, checked } = e.target;
    setSelectedRecebiveisIds(prev => 
      checked ? [...prev, value] : prev.filter(id => id !== value)
    );
    setResultadoCalculo(null); // Resetar cálculo ao mudar seleção
    setMessage(null);
  };

  const handleTaxaChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTaxaMensal(e.target.value);
    setResultadoCalculo(null); // Resetar cálculo ao mudar taxa
    setMessage(null);
  };

  const calcularAntecipacao = () => {
    setMessage(null);
    const taxaNum = parseFloat(taxaMensal);
    if (isNaN(taxaNum) || taxaNum <= 0 || selectedRecebiveisIds.length === 0) {
      setMessage({ type: 'error', text: 'Por favor, selecione recebíveis e insira uma taxa mensal válida.' });
      return;
    }

    const taxaDiaria = taxaNum / 100 / 30; // Convertendo taxa mensal para diária (aproximação)
    let valorTotalFace = 0;
    let valorTotalDesconto = 0;
    const detalhes: CalculoResultado['detalhes'] = [];

    selectedRecebiveisIds.forEach(id => {
      const recebivel = recebiveisDisponiveis.find(r => r.id === id);
      if (recebivel) {
        const dataVencimento = new Date(recebivel.vencimento + 'T00:00:00');
        const diffTime = dataVencimento.getTime() - dataOperacao.getTime();
        const diasAntecipados = Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24))); // Dias até o vencimento

        if (diasAntecipados > 0) {
          const valorFace = recebivel.valor;
          const valorDesconto = valorFace * taxaDiaria * diasAntecipados;
          const valorLiquido = valorFace - valorDesconto;

          valorTotalFace += valorFace;
          valorTotalDesconto += valorDesconto;
          detalhes.push({ 
            id: recebivel.id, 
            valorFace: valorFace, 
            dias: diasAntecipados, 
            desconto: valorDesconto, 
            liquido: valorLiquido 
          });
        } else {
           console.warn(`Recebível ${recebivel.id} não pode ser antecipado (vencido ou vence hoje).`);
        }
      }
    });

    if (detalhes.length === 0) {
        setMessage({ type: 'error', text: 'Nenhum recebível selecionado é válido para antecipação (verifique as datas de vencimento).' });
        setResultadoCalculo(null);
        return;
    }

    setResultadoCalculo({
      valorTotalFace,
      valorTotalDesconto,
      valorTotalLiquido: valorTotalFace - valorTotalDesconto,
      detalhes
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resultadoCalculo) {
      setMessage({ type: 'error', text: 'Por favor, calcule a antecipação antes de confirmar.' });
      return;
    }
    
    setIsLoading(true);
    setMessage(null);

    const dataToSend = {
      cliente_id: 1, // TODO: Obter ID real do cliente
      data_operacao: dataOperacao.toISOString().split('T')[0],
      taxa_mensal: parseFloat(taxaMensal),
      valor_total_face: resultadoCalculo.valorTotalFace,
      valor_total_desconto: resultadoCalculo.valorTotalDesconto,
      valor_total_liquido: resultadoCalculo.valorTotalLiquido,
      usuario_id: 1, // TODO: Obter ID real do usuário logado
      itens: resultadoCalculo.detalhes,
      // observacoes: // TODO: Adicionar campo de observações se necessário
    };

    try {
      const result = await createAntecipacao(dataToSend);
      if (result.success) {
        setMessage({ type: 'success', text: result.message });
        // Limpar seleção e resultado após confirmar
        setSelectedRecebiveisIds([]);
        setResultadoCalculo(null);
        // TODO: Considerar atualizar a lista de recebíveis disponíveis ou recarregar a página
      } else {
        setMessage({ type: 'error', text: result.message });
      }
    } catch (error) {
      console.error('Erro inesperado no formulário de antecipação:', error);
      setMessage({ type: 'error', text: 'Ocorreu um erro inesperado ao registrar a antecipação.' });
    } finally {
      setIsLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
  };

  return (
    <form onSubmit={handleSubmit}>
      {message && (
        <p className={`mb-4 text-sm ${message.type === 'success' ? 'text-green-400' : 'text-red-400'}`}>
          {message.text}
        </p>
      )}
      <div className="mb-6">
        <h3 className="text-lg font-medium mb-2">1. Selecione os Recebíveis</h3>
        <div className="max-h-60 overflow-y-auto border border-gray-600 rounded-md p-4 bg-gray-700/50">
          {recebiveisDisponiveis.length === 0 ? (
            <p className="text-gray-400">Nenhum recebível pendente disponível.</p>
          ) : (
            recebiveisDisponiveis.map(recebivel => (
              <div key={recebivel.id} className="flex items-center mb-2">
                <input
                  type="checkbox"
                  id={recebivel.id}
                  value={recebivel.id}
                  checked={selectedRecebiveisIds.includes(recebivel.id)}
                  onChange={handleCheckboxChange}
                  className="mr-2 h-4 w-4 rounded border-gray-500 text-blue-600 focus:ring-blue-500 bg-gray-800"
                />
                <label htmlFor={recebivel.id} className="text-sm text-gray-300">
                  {recebivel.descricao} - {formatCurrency(recebivel.valor)} (Venc: {new Date(recebivel.vencimento + 'T00:00:00').toLocaleDateString('pt-BR')})
                </label>
              </div>
            ))
          )}
        </div>
      </div>

      <div className="mb-6">
        <h3 className="text-lg font-medium mb-2">2. Informe a Taxa</h3>
        {/* TODO: Adicionar seleção de cliente para buscar taxa padrão? */}
        <label htmlFor="taxaMensal" className="block text-sm font-medium mb-1">
          Taxa de Desconto Mensal (%)
        </label>
        <input
          type="number"
          id="taxaMensal"
          name="taxaMensal"
          value={taxaMensal}
          onChange={handleTaxaChange}
          required
          step="0.01"
          min="0.01"
          className="w-full md:w-1/3 p-2 bg-gray-700 border border-gray-600 rounded-md text-white"
        />
      </div>

      <div className="mb-6">
        <button
          type="button"
          onClick={calcularAntecipacao}
          disabled={selectedRecebiveisIds.length === 0 || !taxaMensal || isLoading}
          className="bg-yellow-600 hover:bg-yellow-700 text-white font-medium py-2 px-4 rounded-md transition duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Calcular Simulação
        </button>
      </div>

      {resultadoCalculo && (
        <div className="mb-6 p-4 border border-gray-600 rounded-md bg-gray-700/50">
          <h3 className="text-lg font-medium mb-3">Resultado da Simulação</h3>
          <p><strong>Data da Operação:</strong> {dataOperacao.toLocaleDateString('pt-BR')}</p>
          <p><strong>Taxa Mensal Aplicada:</strong> {taxaMensal}%</p>
          <p><strong>Valor Total (Face):</strong> {formatCurrency(resultadoCalculo.valorTotalFace)}</p>
          <p><strong>Valor Total Desconto:</strong> {formatCurrency(resultadoCalculo.valorTotalDesconto)}</p>
          <p className="text-xl font-semibold mt-2"><strong>Valor Líquido a Receber:</strong> {formatCurrency(resultadoCalculo.valorTotalLiquido)}</p>
        </div>
      )}

      <div className="mt-8">
        <button
          type="submit"
          disabled={!resultadoCalculo || isLoading}
          className="w-full bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded-md transition duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? 'Registrando...' : 'Confirmar e Registrar Antecipação'}
        </button>
      </div>
    </form>
  );
}

