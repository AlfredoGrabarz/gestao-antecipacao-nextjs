
'use client';

import { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { resetPassword, verifyPasswordResetToken } from '@/lib/auth';

function ResetPasswordFormComponent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = searchParams.get('token');

  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isTokenValid, setIsTokenValid] = useState<boolean | null>(null);
  const [tokenVerificationMessage, setTokenVerificationMessage] = useState<string | null>('Verificando token...');

  useEffect(() => {
    async function checkToken() {
      if (!token) {
        setError('Token não fornecido na URL.');
        setTokenVerificationMessage(null);
        setIsTokenValid(false);
        return;
      }
      try {
        const verification = await verifyPasswordResetToken(token);
        if (verification.valid) {
          setIsTokenValid(true);
          setTokenVerificationMessage(null);
        } else {
          setError(verification.message || 'Token inválido ou expirado.');
          setTokenVerificationMessage(null);
          setIsTokenValid(false);
        }
      } catch (e) {
        setError('Erro ao verificar o token.');
        setTokenVerificationMessage(null);
        setIsTokenValid(false);
      }
    }
    checkToken();
  }, [token]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setMessage(null);
    setIsLoading(true);

    if (password !== confirmPassword) {
      setError('As senhas não coincidem.');
      setIsLoading(false);
      return;
    }
    if (!token) {
        setError('Token não encontrado. Não é possível redefinir a senha.');
        setIsLoading(false);
        return;
    }

    try {
      const result = await resetPassword(token, password);
      if (result.success) {
        setMessage(result.message + ' Você será redirecionado para a página de login em breve.');
        setTimeout(() => {
          router.push('/login');
        }, 3000);
      } else {
        setError(result.message);
      }
    } catch (err) {
      console.error('Erro ao redefinir senha:', err);
      setError('Ocorreu um erro inesperado. Tente novamente.');
    }
    setIsLoading(false);
  };

  if (tokenVerificationMessage) {
    return <p className="text-center text-gray-300">{tokenVerificationMessage}</p>;
  }

  if (isTokenValid === false) {
    return (
        <div className="text-center">
            <p className="text-red-400">{error || 'Não foi possível validar o token de redefinição.'}</p>
            <Link href="/esqueci-senha" className="mt-4 inline-block font-medium text-indigo-400 hover:text-indigo-300">
                Solicitar novo link
            </Link>
        </div>
    );
  }
  
  if (isTokenValid === null) { // Ainda carregando a validação do token
    return <p className="text-center text-gray-300">Verificando token...</p>;
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="password" className="block text-sm font-medium text-gray-300">
          Nova Senha
        </label>
        <div className="mt-1">
          <input
            id="password"
            name="password"
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="appearance-none block w-full px-3 py-2 border border-gray-600 rounded-md shadow-sm placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm bg-gray-700 text-white"
          />
        </div>
      </div>

      <div>
        <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-300">
          Confirmar Nova Senha
        </label>
        <div className="mt-1">
          <input
            id="confirmPassword"
            name="confirmPassword"
            type="password"
            required
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            className="appearance-none block w-full px-3 py-2 border border-gray-600 rounded-md shadow-sm placeholder-gray-500 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm bg-gray-700 text-white"
          />
        </div>
      </div>

      {message && (
        <p className="text-sm text-green-400 text-center">{message}</p>
      )}
      {error && (
        <p className="text-sm text-red-400 text-center">{error}</p>
      )}

      <div>
        <button
          type="submit"
          disabled={isLoading || !isTokenValid}
          className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
        >
          {isLoading ? 'Redefinindo...' : 'Redefinir Senha'}
        </button>
      </div>
    </form>
  );
}

// Componente wrapper para usar Suspense com useSearchParams
export default function ResetPasswordForm() {
    return (
        <Suspense fallback={<div>Carregando formulário...</div>}>
            <ResetPasswordFormComponent />
        </Suspense>
    );
}

