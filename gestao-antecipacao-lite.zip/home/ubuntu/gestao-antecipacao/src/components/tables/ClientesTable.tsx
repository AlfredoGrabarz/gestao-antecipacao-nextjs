// src/components/tables/ClientesTable.tsx

interface Cliente {
  id: number;
  nome: string;
  documento: string;
  tipo_documento: string;
  telefone: string | null;
  email: string | null;
  ativo: boolean;
}

interface ClientesTableProps {
  clientes: Cliente[];
}

export default function ClientesTable({ clientes }: ClientesTableProps) {
  if (!clientes || clientes.length === 0) {
    return <p className="text-gray-500">Nenhum cliente cadastrado ainda.</p>;
  }

  // TODO: Adicionar máscara para documento e telefone

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full bg-gray-700 border border-gray-600 rounded-md">
        <thead>
          <tr className="bg-gray-600">
            <th className="p-3 text-left text-sm font-semibold text-gray-300">Nome / Razão Social</th>
            <th className="p-3 text-left text-sm font-semibold text-gray-300">Documento</th>
            <th className="p-3 text-left text-sm font-semibold text-gray-300">Email</th>
            <th className="p-3 text-left text-sm font-semibold text-gray-300">Telefone</th>
            <th className="p-3 text-left text-sm font-semibold text-gray-300">Status</th>
            {/* TODO: Adicionar coluna de ações (editar, visualizar detalhes) */}
          </tr>
        </thead>
        <tbody>
          {clientes.map((cliente) => (
            <tr key={cliente.id} className="border-b border-gray-600 hover:bg-gray-600/50">
              <td className="p-3 text-sm text-gray-200">{cliente.nome}</td>
              <td className="p-3 text-sm text-gray-200">{cliente.documento} ({cliente.tipo_documento.toUpperCase()})</td>
              <td className="p-3 text-sm text-gray-200">{cliente.email || "-"}</td>
              <td className="p-3 text-sm text-gray-200">{cliente.telefone || "-"}</td>
              <td className="p-3 text-sm text-gray-200">
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${cliente.ativo ? "bg-green-500 text-green-100" : "bg-red-500 text-red-100"}`}>
                  {cliente.ativo ? "Ativo" : "Inativo"}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
