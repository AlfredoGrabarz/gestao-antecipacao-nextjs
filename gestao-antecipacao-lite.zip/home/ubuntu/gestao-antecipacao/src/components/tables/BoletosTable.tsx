// src/components/tables/BoletosTable.tsx

interface Boleto {
  id: number;
  cliente: string;
  cedente: string;
  sacado: string;
  numeroNotaFiscal: string;
  valor: number;
  dataVencimento: string;
  status: string;
}

interface BoletosTableProps {
  boletos: Boleto[];
}

export default function BoletosTable({ boletos }: BoletosTableProps) {
  if (!boletos || boletos.length === 0) {
    return <p className="text-gray-500">Nenhum boleto cadastrado ainda.</p>;
  }

  const formatCurrency = (value: number) => {
    return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString + "T00:00:00"); // Adjust for timezone if needed
    return date.toLocaleDateString("pt-BR");
  };

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full bg-gray-700 border border-gray-600 rounded-md">
        <thead>
          <tr className="bg-gray-600">
            <th className="p-3 text-left text-sm font-semibold text-gray-300">Cliente</th>
            <th className="p-3 text-left text-sm font-semibold text-gray-300">Cedente</th>
            <th className="p-3 text-left text-sm font-semibold text-gray-300">Sacado</th>
            <th className="p-3 text-left text-sm font-semibold text-gray-300">NF</th>
            <th className="p-3 text-left text-sm font-semibold text-gray-300">Valor</th>
            <th className="p-3 text-left text-sm font-semibold text-gray-300">Vencimento</th>
            <th className="p-3 text-left text-sm font-semibold text-gray-300">Status</th>
            {/* TODO: Adicionar coluna de ações (editar, excluir, antecipar) */}
          </tr>
        </thead>
        <tbody>
          {boletos.map((boleto) => (
            <tr key={boleto.id} className="border-b border-gray-600 hover:bg-gray-600/50">
              <td className="p-3 text-sm text-gray-200">{boleto.cliente}</td>
              <td className="p-3 text-sm text-gray-200">{boleto.cedente}</td>
              <td className="p-3 text-sm text-gray-200">{boleto.sacado}</td>
              <td className="p-3 text-sm text-gray-200">{boleto.numeroNotaFiscal}</td>
              <td className="p-3 text-sm text-gray-200">{formatCurrency(boleto.valor)}</td>
              <td className="p-3 text-sm text-gray-200">{formatDate(boleto.dataVencimento)}</td>
              <td className="p-3 text-sm text-gray-200">
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${boleto.status === "pendente" ? "bg-yellow-500 text-yellow-900" : boleto.status === "antecipado" ? "bg-blue-500 text-blue-100" : boleto.status === "liquidado" ? "bg-green-500 text-green-100" : "bg-red-500 text-red-100"}`}>
                  {boleto.status}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
