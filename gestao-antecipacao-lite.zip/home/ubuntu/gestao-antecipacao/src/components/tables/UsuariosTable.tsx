// src/components/tables/UsuariosTable.tsx

interface Usuario {
  id: number;
  nome: string;
  email: string;
  perfil: string;
  ativo: boolean;
}

interface UsuariosTableProps {
  usuarios: Usuario[];
}

export default function UsuariosTable({ usuarios }: UsuariosTableProps) {
  if (!usuarios || usuarios.length === 0) {
    return <p className="text-gray-500">Nenhum usuário cadastrado ainda.</p>;
  }

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full bg-gray-700 border border-gray-600 rounded-md">
        <thead>
          <tr className="bg-gray-600">
            <th className="p-3 text-left text-sm font-semibold text-gray-300">Nome</th>
            <th className="p-3 text-left text-sm font-semibold text-gray-300">Email</th>
            <th className="p-3 text-left text-sm font-semibold text-gray-300">Perfil</th>
            <th className="p-3 text-left text-sm font-semibold text-gray-300">Status</th>
            {/* TODO: Adicionar coluna de ações (editar, ativar/desativar) */}
          </tr>
        </thead>
        <tbody>
          {usuarios.map((usuario) => (
            <tr key={usuario.id} className="border-b border-gray-600 hover:bg-gray-600/50">
              <td className="p-3 text-sm text-gray-200">{usuario.nome}</td>
              <td className="p-3 text-sm text-gray-200">{usuario.email}</td>
              <td className="p-3 text-sm text-gray-200 capitalize">{usuario.perfil}</td>
              <td className="p-3 text-sm text-gray-200">
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${usuario.ativo ? "bg-green-500 text-green-100" : "bg-red-500 text-red-100"}`}>
                  {usuario.ativo ? "Ativo" : "Inativo"}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
