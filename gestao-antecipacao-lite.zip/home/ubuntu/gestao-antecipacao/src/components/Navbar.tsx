import Link from 'next/link';

export default function Navbar() {
  return (
    <nav className="bg-gray-800 p-4">
      <div className="container mx-auto flex justify-between items-center">
        <Link href="/" className="text-white text-xl font-bold">
          Gestão de Antecipação
        </Link>
        <div className="space-x-4">
          <Link href="/dashboard" className="text-gray-300 hover:text-white">Dashboard</Link>
          <Link href="/cheques" className="text-gray-300 hover:text-white">Cheques</Link>
          <Link href="/boletos" className="text-gray-300 hover:text-white">Boletos</Link>
          <Link href="/clientes" className="text-gray-300 hover:text-white">Clientes</Link>
          <Link href="/antecipacoes" className="text-gray-300 hover:text-white">Antecipações</Link>
          <Link href="/usuarios" className="text-gray-300 hover:text-white">Usuários</Link>
          {/* Adicionar link de Login/Logout posteriormente */}
        </div>
      </div>
    </nav>
  );
}
